import pyodbc
import os
import sys

def apply_schema():
    server = 'rakat-sqlsrv-01.database.windows.net'
    database = 'free-sql-db-2967320'
    username = 'sqladmin'
    password = 'Agile_group'
    driver = '{ODBC Driver 18 for SQL Server}'

    conn_str = f'DRIVER={driver};SERVER={server};PORT=1433;DATABASE={database};UID={username};PWD={password};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;'

    try:
        print("Connecting to Azure SQL...")
        conn = pyodbc.connect(conn_str, autocommit=True)
        cursor = conn.cursor()
        
        schema_path = '/app/create_tables.sql'
        print(f"Reading schema from {schema_path}...")
        with open(schema_path, 'r') as f:
            sql = f.read()

        # Split by GO
        commands = sql.split('GO')
        
        for cmd in commands:
            cmd = cmd.strip()
            if cmd:
                print(f"Executing: {cmd[:50]}...")
                cursor.execute(cmd)
        
        print("Schema applied successfully!")
        conn.close()
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    apply_schema()
