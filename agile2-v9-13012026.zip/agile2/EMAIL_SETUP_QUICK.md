# Email Service Configuration - Quick Reference

## ✅ MailHog Status

**MailHog is running correctly!** It's working as intended for development/testing.

However, MailHog **does NOT send real emails** - it only captures them for testing. For production use, you need a real email service.

---

## 🚀 Recommended: SendGrid (Free Tier)

**Why SendGrid?**
- ✅ 100 emails/day FREE forever
- ✅ 5-minute setup
- ✅ No credit card required
- ✅ Excellent deliverability
- ✅ Works with your existing code

### Quick Setup (5 minutes):

1. **Sign up**: [https://signup.sendgrid.com/](https://signup.sendgrid.com/)

2. **Create API Key**:
   - Dashboard → Settings → API Keys
   - Click "Create API Key"
   - Name: "Contract Management System"
   - Permissions: "Mail Send" → Full Access
   - **Copy the key immediately!**

3. **Update `docker/.env`**:
   ```bash
   SENDGRID_API_KEY=SG.your_actual_key_here
   FROM_EMAIL=noreply@yourcompany.com
   SMTP_HOST=smtp.sendgrid.net
   SMTP_PORT=587
   SMTP_USER=apikey
   ```

4. **Update `docker-compose.yml`** - Change worker environment:
   ```yaml
   legal-notify-worker:
     environment:
       - SMTP_HOST=smtp.sendgrid.net
       - SMTP_PORT=587
       - SMTP_USER=apikey
       - SMTP_PASSWORD=${SENDGRID_API_KEY}
       - FROM_EMAIL=${FROM_EMAIL}
   ```

5. **Restart**:
   ```bash
   docker compose down
   docker compose up -d
   ```

**Done!** Your system now sends real emails.

---

## 📧 Alternative Options

### Option 2: Gmail (Free, 500/day)
- Good for: Testing, small projects
- Setup time: 10 minutes
- Requires: App password (2FA enabled)

### Option 3: Azure Communication Services
- Good for: Azure deployments
- Cost: $0.00025 per email
- Setup time: 15 minutes

### Option 4: AWS SES
- Good for: AWS deployments
- Cost: $0.10 per 1,000 emails
- Setup time: 20 minutes

---

## 📊 Comparison

| Service | Free Tier | Setup | Best For |
|---------|-----------|-------|----------|
| **SendGrid** | 100/day | 5 min | Most projects ⭐ |
| **Gmail** | 500/day | 10 min | Testing |
| **Azure ACS** | 100/month | 15 min | Azure users |
| **AWS SES** | 62k/month* | 20 min | AWS users |

*Only if sent from EC2

---

## 🔧 Files to Update

1. **`docker/.env`** - Add email credentials
2. **`docker-compose.yml`** - Update worker environment variables
3. **Restart containers**

See [EMAIL_SERVICE_SETUP.md](./EMAIL_SERVICE_SETUP.md) for detailed instructions.

---

## ❓ Need Help?

I can help you set up any of these services. Just let me know which one you prefer!
