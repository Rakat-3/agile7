import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './index.css';

const API_BASE = 'http://localhost:8000';

function App() {
  const [contracts, setContracts] = useState([]);
  const [selectedContract, setSelectedContract] = useState(null);
  const [loading, setLoading] = useState(true);

  // Form State
  const [formData, setFormData] = useState({
    providersName: '',
    providersBudget: '',
    providersComment: '',
    meetRequirement: 'Yes'
  });

  useEffect(() => {
    fetchContracts();
  }, []);

  const fetchContracts = async () => {
    try {
      const res = await axios.get(`${API_BASE}/api/providers/contracts`);
      // Filter to show only Submitted and Active contracts
      const filtered = res.data.filter(c =>
        c.ContractStatus === 'Submitted' || c.ContractStatus === 'Active'
      );
      setContracts(filtered);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching contracts:", error);
      setLoading(false);
    }
  };

  const isDeadlinePassed = (deadline) => {
    if (!deadline) return false;
    const deadlineDate = new Date(deadline);
    const now = new Date();
    return deadlineDate < now;
  };

  const handleOpenModal = (contract) => {
    setSelectedContract(contract);
    setFormData({
      providersName: '',
      providersBudget: '',
      providersComment: '',
      meetRequirement: 'Yes'
    });
  };

  const handleViewDetails = (contract) => {
    alert(`Contract Details:\n\nTitle: ${contract.ContractTitle}\nType: ${contract.ContractType}\nBudget: $${contract.Budget}\nStatus: ${contract.ContractStatus}\n\nThis contract is now active and finalized.`);
  };

  const handleCloseModal = () => {
    setSelectedContract(null);
  };

  const handleSubmitCallback = async (e) => {
    e.preventDefault();
    if (!selectedContract) return;

    try {
      const payload = {
        ...formData,
        providersBudget: parseFloat(formData.providersBudget)
      };

      await axios.patch(`${API_BASE}/api/providers/contracts/${selectedContract.ContractId}`, payload);

      alert('Offer submitted successfully!');
      handleCloseModal();
      fetchContracts(); // Refresh list
    } catch (error) {
      console.error("Error submitting offer:", error);
      alert('Failed to submit offer. Please try again.');
    }
  };

  const renderActionButton = (contract) => {
    if (contract.ContractStatus === 'Active') {
      return (
        <button
          className="btn btn-secondary"
          onClick={() => handleViewDetails(contract)}
        >
          View Details
        </button>
      );
    }

    // For Submitted contracts
    if (isDeadlinePassed(contract.Deadline)) {
      return (
        <button
          className="btn"
          disabled
          style={{ opacity: 0.5, cursor: 'not-allowed' }}
          title="Deadline has passed"
        >
          Deadline Passed
        </button>
      );
    }

    return (
      <button
        className="btn"
        onClick={() => handleOpenModal(contract)}
      >
        Submit Offer
      </button>
    );
  };

  return (
    <div className="container">
      <h1>Provider Portal</h1>

      {loading ? (
        <div style={{ textAlign: 'center', marginTop: '2rem' }}>Loading contracts...</div>
      ) : (
        <div className="contract-list">
          {contracts.length === 0 ? (
            <div style={{ textAlign: 'center', color: '#94a3b8' }}>No contracts available.</div>
          ) : (
            contracts.map(contract => (
              <div key={contract.ContractId} className="contract-card">
                <div className="field">
                  <span className="label">Title</span>
                  <span className="value">{contract.ContractTitle}</span>
                  <div style={{ fontSize: '0.875rem', color: '#94a3b8', marginTop: '0.25rem' }}>
                    {contract.Description?.substring(0, 100)}...
                  </div>
                </div>

                <div className="field">
                  <span className="label">Type</span>
                  <span className="value">{contract.ContractType}</span>
                </div>

                <div className="field">
                  <span className="label">Budget</span>
                  <span className="value">${contract.Budget?.toLocaleString() || 'N/A'}</span>
                </div>

                <div className="field">
                  <span className="label">Status</span>
                  <span className={`status-badge ${contract.ContractStatus === 'Active' ? 'status-active' : ''}`}>
                    {contract.ContractStatus}
                  </span>
                  {contract.Deadline && contract.ContractStatus === 'Submitted' && (
                    <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '0.25rem' }}>
                      Deadline: {new Date(contract.Deadline).toLocaleDateString()}
                    </div>
                  )}
                </div>

                {renderActionButton(contract)}
              </div>
            ))
          )}
        </div>
      )}

      {selectedContract && (
        <div className="modal-overlay" onClick={(e) => { if (e.target.className === 'modal-overlay') handleCloseModal() }}>
          <div className="modal-content">
            <h2 style={{ marginTop: 0, marginBottom: '1.5rem' }}>Submit Offer</h2>
            <div style={{ marginBottom: '1.5rem', opacity: 0.8 }}>
              For: <strong>{selectedContract.ContractTitle}</strong>
              <br />
              <small>Target Budget: ${selectedContract.Budget}</small>
              {selectedContract.Deadline && (
                <>
                  <br />
                  <small>Deadline: {new Date(selectedContract.Deadline).toLocaleDateString()}</small>
                </>
              )}
            </div>

            <form onSubmit={handleSubmitCallback}>
              <div className="form-group">
                <label>Provider Name/Company</label>
                <input
                  type="text"
                  className="form-input"
                  required
                  value={formData.providersName}
                  onChange={e => setFormData({ ...formData, providersName: e.target.value })}
                  placeholder="e.g. Acme Corp"
                />
              </div>

              <div className="form-group">
                <label>Offer Amount ($)</label>
                <input
                  type="number"
                  className="form-input"
                  required
                  value={formData.providersBudget}
                  onChange={e => setFormData({ ...formData, providersBudget: e.target.value })}
                  placeholder="0.00"
                />
              </div>

              <div className="form-group">
                <label>Can Meet Requirements?</label>
                <select
                  className="form-select"
                  value={formData.meetRequirement}
                  onChange={e => setFormData({ ...formData, meetRequirement: e.target.value })}
                >
                  <option value="Yes">Yes</option>
                  <option value="No">No</option>
                  <option value="Partially">Partially</option>
                </select>
              </div>

              <div className="form-group">
                <label>Comments / Details</label>
                <textarea
                  className="form-textarea"
                  rows="3"
                  value={formData.providersComment}
                  onChange={e => setFormData({ ...formData, providersComment: e.target.value })}
                  placeholder="Describe your offer..."
                ></textarea>
              </div>

              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>Cancel</button>
                <button type="submit" className="btn">Submit Offer</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
