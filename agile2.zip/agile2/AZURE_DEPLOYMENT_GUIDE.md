# Azure Deployment Guide - Contract Management System

This guide provides comprehensive instructions for deploying your Docker-based Contract Management System to Microsoft Azure using **Azure Container Apps** and related services.

## 📋 Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Prerequisites](#prerequisites)
3. [Azure Services Required](#azure-services-required)
4. [Deployment Options](#deployment-options)
5. [Step-by-Step Deployment](#step-by-step-deployment)
6. [Environment Configuration](#environment-configuration)
7. [CI/CD Pipeline Setup](#cicd-pipeline-setup)
8. [Cost Optimization](#cost-optimization)
9. [Monitoring and Troubleshooting](#monitoring-and-troubleshooting)

---

## 🏗 Architecture Overview

Your application consists of the following components:

| Component | Current Setup | Azure Service |
|-----------|---------------|---------------|
| **Camunda BPM** | Docker container | Azure Container Apps |
| **PostgreSQL** (Camunda DB) | Docker container | Azure Database for PostgreSQL |
| **FastAPI Backend** | Docker container | Azure Container Apps |
| **React Frontend** | Docker container | Azure Container Apps / Azure Static Web Apps |
| **Azure SQL** | External service | Azure SQL Database (existing) |
| **MailHog** | Docker container | Azure Communication Services / SendGrid |
| **Workers (5x)** | Docker containers | Azure Container Apps |
| **Nginx Proxy** | Docker container | Azure Container Apps / Application Gateway |

### Recommended Azure Architecture

```mermaid
graph TB
    subgraph "Azure Cloud"
        subgraph "Container Apps Environment"
            FE[Frontend Container App]
            BE[Backend Container App]
            CAM[Camunda Container App]
            W1[Worker: Legal Notify]
            W2[Worker: Provider Notify]
            W3[Worker: Store Create]
            W4[Worker: Store Contract]
            W5[Worker: Store Reject]
            PROXY[Nginx Proxy]
        end
        
        subgraph "Data Layer"
            PSQL[Azure PostgreSQL<br/>Camunda DB]
            ASQL[Azure SQL Database<br/>Contract Data]
        end
        
        subgraph "Supporting Services"
            ACR[Azure Container Registry]
            EMAIL[Azure Communication<br/>Services / SendGrid]
            APPINS[Application Insights]
        end
        
        PROXY --> FE
        PROXY --> BE
        FE --> BE
        BE --> CAM
        BE --> ASQL
        CAM --> PSQL
        W1 --> CAM
        W2 --> CAM
        W3 --> CAM
        W4 --> CAM
        W5 --> CAM
        W1 --> EMAIL
        W2 --> EMAIL
        W3 --> ASQL
        W4 --> ASQL
        W5 --> ASQL
    end
    
    USER[Users] --> PROXY
```

---

## ✅ Prerequisites

Before starting, ensure you have:

- **Azure Subscription** with appropriate permissions
- **Azure CLI** installed ([Install Guide](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli))
- **Docker** installed locally
- **Git** for version control
- **Existing Azure SQL Database** (already configured)

### Install Azure CLI

```bash
# Windows (PowerShell)
winget install -e --id Microsoft.AzureCLI

# Verify installation
az --version

# Login to Azure
az login
```

---

## 🔧 Azure Services Required

### 1. Azure Container Registry (ACR)
Stores your Docker images securely.

### 2. Azure Container Apps Environment
Hosts all your containerized services with built-in scaling and networking.

### 3. Azure Database for PostgreSQL
Managed PostgreSQL for Camunda's internal database.

### 4. Azure SQL Database
Already configured for contract data storage.

### 5. Azure Communication Services or SendGrid
Replaces MailHog for production email delivery.

### 6. Azure Application Insights
Monitoring and logging for all services.

### 7. Azure Key Vault (Optional but Recommended)
Secure storage for secrets and connection strings.

---

## 🚀 Deployment Options

### Option 1: Azure Container Apps (Recommended)
**Best for:** Microservices architecture, auto-scaling, serverless containers

**Pros:**
- Fully managed Kubernetes-based platform
- Built-in scaling (0 to N instances)
- Integrated with Azure services
- Pay-per-use pricing
- Easy networking between containers

**Cons:**
- Slightly higher cost than VMs for always-on services
- Less control over infrastructure

### Option 2: Azure Kubernetes Service (AKS)
**Best for:** Complex orchestration, full Kubernetes control

**Pros:**
- Full Kubernetes features
- Maximum flexibility
- Better for large-scale deployments

**Cons:**
- More complex to manage
- Requires Kubernetes expertise
- Higher operational overhead

### Option 3: Azure App Service for Containers
**Best for:** Simple web apps, single container deployments

**Pros:**
- Easy to use
- Good for simple scenarios

**Cons:**
- Limited multi-container support
- Not ideal for your complex architecture

---

## 📝 Step-by-Step Deployment

We'll use **Azure Container Apps** as it's the best fit for your architecture.

### Phase 1: Initial Setup

#### 1.1 Set Environment Variables

Create a deployment configuration file:

```bash
# Create deployment-config.sh (or .ps1 for PowerShell)
# Save this in your project root

# Azure Configuration
RESOURCE_GROUP="rg-contract-mgmt-prod"
LOCATION="eastus"
ACR_NAME="acrcontractmgmt"  # Must be globally unique, lowercase, no hyphens
CONTAINER_ENV="env-contract-mgmt"

# Database Configuration
POSTGRES_SERVER="psql-camunda-prod"
POSTGRES_DB="camunda"
POSTGRES_ADMIN_USER="camundaadmin"
POSTGRES_ADMIN_PASSWORD="YourSecurePassword123!"  # Change this!

# Email Service (choose one)
EMAIL_SERVICE="sendgrid"  # or "azure-communication-services"
SENDGRID_API_KEY="your-sendgrid-api-key"  # If using SendGrid

# Application Insights
APPINSIGHTS_NAME="appi-contract-mgmt"
```

#### 1.2 Create Resource Group

```bash
az group create \
  --name $RESOURCE_GROUP \
  --location $LOCATION
```

### Phase 2: Container Registry Setup

#### 2.1 Create Azure Container Registry

```bash
az acr create \
  --resource-group $RESOURCE_GROUP \
  --name $ACR_NAME \
  --sku Basic \
  --admin-enabled true

# Get ACR credentials
ACR_USERNAME=$(az acr credential show --name $ACR_NAME --query username -o tsv)
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query "passwords[0].value" -o tsv)
ACR_LOGIN_SERVER=$(az acr show --name $ACR_NAME --query loginServer -o tsv)

echo "ACR Login Server: $ACR_LOGIN_SERVER"
```

#### 2.2 Build and Push Docker Images

```bash
# Login to ACR
az acr login --name $ACR_NAME

# Navigate to your project directory
cd c:\Users\Test\Desktop\agile-final\agile2

# Build and push Backend
cd backend
docker build -t $ACR_LOGIN_SERVER/backend:latest .
docker push $ACR_LOGIN_SERVER/backend:latest

# Build and push Frontend
cd ../frontend
docker build -t $ACR_LOGIN_SERVER/frontend:latest .
docker push $ACR_LOGIN_SERVER/frontend:latest

# Build and push Workers
cd ../docker
docker build -f Dockerfile.worker -t $ACR_LOGIN_SERVER/worker:latest .
docker push $ACR_LOGIN_SERVER/worker:latest

# Camunda uses official image, no build needed
```

### Phase 3: Database Setup

#### 3.1 Create Azure Database for PostgreSQL

```bash
az postgres flexible-server create \
  --resource-group $RESOURCE_GROUP \
  --name $POSTGRES_SERVER \
  --location $LOCATION \
  --admin-user $POSTGRES_ADMIN_USER \
  --admin-password $POSTGRES_ADMIN_PASSWORD \
  --sku-name Standard_B2s \
  --tier Burstable \
  --version 14 \
  --storage-size 32 \
  --public-access 0.0.0.0

# Create database
az postgres flexible-server db create \
  --resource-group $RESOURCE_GROUP \
  --server-name $POSTGRES_SERVER \
  --database-name $POSTGRES_DB

# Get connection string
POSTGRES_CONNECTION_STRING="postgresql://${POSTGRES_ADMIN_USER}:${POSTGRES_ADMIN_PASSWORD}@${POSTGRES_SERVER}.postgres.database.azure.com:5432/${POSTGRES_DB}?sslmode=require"
```

> [!IMPORTANT]
> Configure firewall rules to allow Azure services to access PostgreSQL:
> ```bash
> az postgres flexible-server firewall-rule create \
>   --resource-group $RESOURCE_GROUP \
>   --name $POSTGRES_SERVER \
>   --rule-name AllowAzureServices \
>   --start-ip-address 0.0.0.0 \
>   --end-ip-address 0.0.0.0
> ```

### Phase 4: Email Service Setup

#### Option A: SendGrid (Recommended for simplicity)

```bash
# Create SendGrid account via Azure Marketplace
# Or sign up at https://sendgrid.com/

# Get API key from SendGrid dashboard
# Set SENDGRID_API_KEY variable
```

#### Option B: Azure Communication Services

```bash
# Create Communication Service
az communication create \
  --name "acs-contract-mgmt" \
  --resource-group $RESOURCE_GROUP \
  --location "global" \
  --data-location "United States"

# Get connection string
ACS_CONNECTION_STRING=$(az communication list-key \
  --name "acs-contract-mgmt" \
  --resource-group $RESOURCE_GROUP \
  --query primaryConnectionString -o tsv)
```

### Phase 5: Application Insights

```bash
az monitor app-insights component create \
  --app $APPINSIGHTS_NAME \
  --location $LOCATION \
  --resource-group $RESOURCE_GROUP \
  --application-type web

# Get instrumentation key
APPINSIGHTS_KEY=$(az monitor app-insights component show \
  --app $APPINSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --query instrumentationKey -o tsv)
```

### Phase 6: Container Apps Environment

#### 6.1 Create Container Apps Environment

```bash
az containerapp env create \
  --name $CONTAINER_ENV \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION
```

#### 6.2 Deploy Camunda Container App

```bash
az containerapp create \
  --name camunda \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_ENV \
  --image camunda/camunda-bpm-platform:run-latest \
  --target-port 8080 \
  --ingress external \
  --min-replicas 1 \
  --max-replicas 3 \
  --cpu 1.0 \
  --memory 2.0Gi \
  --env-vars \
    DB_DRIVER="org.postgresql.Driver" \
    DB_URL="jdbc:postgresql://${POSTGRES_SERVER}.postgres.database.azure.com:5432/${POSTGRES_DB}?sslmode=require" \
    DB_USERNAME="$POSTGRES_ADMIN_USER" \
    DB_PASSWORD="$POSTGRES_ADMIN_PASSWORD" \
    CAMUNDA_CONNECTOR_HTTP_ENABLED="true"

# Get Camunda URL
CAMUNDA_URL=$(az containerapp show \
  --name camunda \
  --resource-group $RESOURCE_GROUP \
  --query properties.configuration.ingress.fqdn -o tsv)

echo "Camunda URL: https://$CAMUNDA_URL"
```

#### 6.3 Deploy Backend Container App

```bash
az containerapp create \
  --name backend \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_ENV \
  --image $ACR_LOGIN_SERVER/backend:latest \
  --registry-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 8000 \
  --ingress external \
  --min-replicas 1 \
  --max-replicas 5 \
  --cpu 0.5 \
  --memory 1.0Gi \
  --env-vars \
    SMTP_HOST="smtp.sendgrid.net" \
    SMTP_PORT="587" \
    SENDGRID_API_KEY="$SENDGRID_API_KEY" \
    AZURE_SQL_SERVER="$AZURE_SQL_SERVER" \
    AZURE_SQL_DATABASE="$AZURE_SQL_DATABASE" \
    AZURE_SQL_USER="$AZURE_SQL_USER" \
    AZURE_SQL_PASSWORD="$AZURE_SQL_PASSWORD" \
    CAMUNDA_URL="https://$CAMUNDA_URL" \
    APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=$APPINSIGHTS_KEY"

# Get Backend URL
BACKEND_URL=$(az containerapp show \
  --name backend \
  --resource-group $RESOURCE_GROUP \
  --query properties.configuration.ingress.fqdn -o tsv)

echo "Backend URL: https://$BACKEND_URL"
```

#### 6.4 Deploy Frontend Container App

```bash
az containerapp create \
  --name frontend \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_ENV \
  --image $ACR_LOGIN_SERVER/frontend:latest \
  --registry-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --target-port 5173 \
  --ingress external \
  --min-replicas 1 \
  --max-replicas 3 \
  --cpu 0.25 \
  --memory 0.5Gi \
  --env-vars \
    VITE_API_URL="https://$BACKEND_URL"

# Get Frontend URL
FRONTEND_URL=$(az containerapp show \
  --name frontend \
  --resource-group $RESOURCE_GROUP \
  --query properties.configuration.ingress.fqdn -o tsv)

echo "Frontend URL: https://$FRONTEND_URL"
```

#### 6.5 Deploy Worker Container Apps

```bash
# Legal Notify Worker
az containerapp create \
  --name legal-notify-worker \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_ENV \
  --image $ACR_LOGIN_SERVER/worker:latest \
  --registry-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --ingress internal \
  --min-replicas 1 \
  --max-replicas 2 \
  --cpu 0.25 \
  --memory 0.5Gi \
  --command "python" "email_worker.py" \
  --env-vars \
    ENGINE_REST="https://$CAMUNDA_URL/engine-rest" \
    CAMUNDA_USER="demo" \
    CAMUNDA_PASS="demo" \
    SMTP_HOST="smtp.sendgrid.net" \
    SMTP_PORT="587" \
    SENDGRID_API_KEY="$SENDGRID_API_KEY" \
    TOPIC_NAME="notify-legal" \
    FROM_EMAIL="noreply@yourcompany.com"

# Provider Notify Worker
az containerapp create \
  --name provider-notify-worker \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_ENV \
  --image $ACR_LOGIN_SERVER/worker:latest \
  --registry-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --ingress internal \
  --min-replicas 1 \
  --max-replicas 2 \
  --cpu 0.25 \
  --memory 0.5Gi \
  --command "python" "email_worker.py" \
  --env-vars \
    ENGINE_REST="https://$CAMUNDA_URL/engine-rest" \
    CAMUNDA_USER="demo" \
    CAMUNDA_PASS="demo" \
    SMTP_HOST="smtp.sendgrid.net" \
    SMTP_PORT="587" \
    SENDGRID_API_KEY="$SENDGRID_API_KEY" \
    TOPIC_NAME="notify-provider-manager" \
    FROM_EMAIL="noreply@yourcompany.com"

# Store Create Contract Worker
az containerapp create \
  --name store-create-worker \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_ENV \
  --image $ACR_LOGIN_SERVER/worker:latest \
  --registry-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --ingress internal \
  --min-replicas 1 \
  --max-replicas 3 \
  --cpu 0.25 \
  --memory 0.5Gi \
  --command "python" "worker_store_create_contract.py" \
  --env-vars \
    ENGINE_REST="https://$CAMUNDA_URL/engine-rest" \
    CAMUNDA_USER="demo" \
    CAMUNDA_PASS="demo" \
    TOPIC_NAME="store-create-contract" \
    AZURE_SQL_SERVER="$AZURE_SQL_SERVER" \
    AZURE_SQL_DATABASE="$AZURE_SQL_DATABASE" \
    AZURE_SQL_USER="$AZURE_SQL_USER" \
    AZURE_SQL_PASSWORD="$AZURE_SQL_PASSWORD"

# Store Contract Worker
az containerapp create \
  --name store-contract-worker \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_ENV \
  --image $ACR_LOGIN_SERVER/worker:latest \
  --registry-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --ingress internal \
  --min-replicas 1 \
  --max-replicas 3 \
  --cpu 0.25 \
  --memory 0.5Gi \
  --command "python" "worker_store_contract.py" \
  --env-vars \
    ENGINE_REST="https://$CAMUNDA_URL/engine-rest" \
    CAMUNDA_USER="demo" \
    CAMUNDA_PASS="demo" \
    TOPIC_NAME="store-contract" \
    AZURE_SQL_SERVER="$AZURE_SQL_SERVER" \
    AZURE_SQL_DATABASE="$AZURE_SQL_DATABASE" \
    AZURE_SQL_USER="$AZURE_SQL_USER" \
    AZURE_SQL_PASSWORD="$AZURE_SQL_PASSWORD"

# Store Reject Contract Worker
az containerapp create \
  --name store-reject-worker \
  --resource-group $RESOURCE_GROUP \
  --environment $CONTAINER_ENV \
  --image $ACR_LOGIN_SERVER/worker:latest \
  --registry-server $ACR_LOGIN_SERVER \
  --registry-username $ACR_USERNAME \
  --registry-password $ACR_PASSWORD \
  --ingress internal \
  --min-replicas 1 \
  --max-replicas 3 \
  --cpu 0.25 \
  --memory 0.5Gi \
  --command "python" "worker_store_reject_contract.py" \
  --env-vars \
    ENGINE_REST="https://$CAMUNDA_URL/engine-rest" \
    CAMUNDA_USER="demo" \
    CAMUNDA_PASS="demo" \
    TOPIC_NAME="store-reject-contract" \
    AZURE_SQL_SERVER="$AZURE_SQL_SERVER" \
    AZURE_SQL_DATABASE="$AZURE_SQL_DATABASE" \
    AZURE_SQL_USER="$AZURE_SQL_USER" \
    AZURE_SQL_PASSWORD="$AZURE_SQL_PASSWORD"
```

---

## 🔐 Environment Configuration

### Using Azure Key Vault (Recommended)

```bash
# Create Key Vault
az keyvault create \
  --name "kv-contract-mgmt" \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION

# Store secrets
az keyvault secret set --vault-name "kv-contract-mgmt" --name "AzureSqlPassword" --value "$AZURE_SQL_PASSWORD"
az keyvault secret set --vault-name "kv-contract-mgmt" --name "PostgresPassword" --value "$POSTGRES_ADMIN_PASSWORD"
az keyvault secret set --vault-name "kv-contract-mgmt" --name "SendGridApiKey" --value "$SENDGRID_API_KEY"

# Grant Container Apps access to Key Vault
# (Requires managed identity configuration)
```

### Environment Variables Checklist

Ensure these are configured for each service:

**Backend:**
- `AZURE_SQL_SERVER`
- `AZURE_SQL_DATABASE`
- `AZURE_SQL_USER`
- `AZURE_SQL_PASSWORD`
- `SMTP_HOST`
- `SMTP_PORT`
- `SENDGRID_API_KEY`
- `CAMUNDA_URL`

**Workers:**
- `ENGINE_REST`
- `CAMUNDA_USER`
- `CAMUNDA_PASS`
- `AZURE_SQL_SERVER` (for storage workers)
- `AZURE_SQL_DATABASE` (for storage workers)
- `AZURE_SQL_USER` (for storage workers)
- `AZURE_SQL_PASSWORD` (for storage workers)
- `SMTP_HOST` (for email workers)
- `SENDGRID_API_KEY` (for email workers)

---

## 🔄 CI/CD Pipeline Setup

### GitHub Actions Workflow

Create `.github/workflows/azure-deploy.yml`:

```yaml
name: Deploy to Azure Container Apps

on:
  push:
    branches: [ main ]
  workflow_dispatch:

env:
  AZURE_RESOURCE_GROUP: rg-contract-mgmt-prod
  ACR_NAME: acrcontractmgmt
  CONTAINER_ENV: env-contract-mgmt

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
    
    - name: Azure Login
      uses: azure/login@v1
      with:
        creds: ${{ secrets.AZURE_CREDENTIALS }}
    
    - name: Build and push Backend
      run: |
        az acr build \
          --registry ${{ env.ACR_NAME }} \
          --image backend:${{ github.sha }} \
          --image backend:latest \
          --file backend/dockerfile \
          backend/
    
    - name: Build and push Frontend
      run: |
        az acr build \
          --registry ${{ env.ACR_NAME }} \
          --image frontend:${{ github.sha }} \
          --image frontend:latest \
          --file frontend/Dockerfile \
          frontend/
    
    - name: Build and push Workers
      run: |
        az acr build \
          --registry ${{ env.ACR_NAME }} \
          --image worker:${{ github.sha }} \
          --image worker:latest \
          --file docker/Dockerfile.worker \
          docker/
    
    - name: Update Backend Container App
      run: |
        az containerapp update \
          --name backend \
          --resource-group ${{ env.AZURE_RESOURCE_GROUP }} \
          --image ${{ env.ACR_NAME }}.azurecr.io/backend:${{ github.sha }}
    
    - name: Update Frontend Container App
      run: |
        az containerapp update \
          --name frontend \
          --resource-group ${{ env.AZURE_RESOURCE_GROUP }} \
          --image ${{ env.ACR_NAME }}.azurecr.io/frontend:${{ github.sha }}
    
    - name: Update Worker Container Apps
      run: |
        for worker in legal-notify-worker provider-notify-worker store-create-worker store-contract-worker store-reject-worker; do
          az containerapp update \
            --name $worker \
            --resource-group ${{ env.AZURE_RESOURCE_GROUP }} \
            --image ${{ env.ACR_NAME }}.azurecr.io/worker:${{ github.sha }}
        done
```

### Setup GitHub Secrets

```bash
# Create service principal
az ad sp create-for-rbac \
  --name "sp-contract-mgmt-github" \
  --role contributor \
  --scopes /subscriptions/{subscription-id}/resourceGroups/$RESOURCE_GROUP \
  --sdk-auth

# Copy the output JSON and add to GitHub Secrets as AZURE_CREDENTIALS
```

---

## 💰 Cost Optimization

### Estimated Monthly Costs

| Service | Configuration | Estimated Cost |
|---------|--------------|----------------|
| Container Apps (9 instances) | 0.5-1.0 vCPU, 1-2GB RAM | $50-150 |
| Azure PostgreSQL | Burstable B2s | $30-50 |
| Azure SQL Database | Existing | Variable |
| Container Registry | Basic | $5 |
| Application Insights | 5GB/month | $10-20 |
| SendGrid | 100 emails/day free | $0-15 |
| **Total** | | **$95-240/month** |

### Cost Reduction Strategies

1. **Scale to Zero**: Configure Container Apps to scale to 0 replicas during off-hours
   ```bash
   az containerapp update \
     --name frontend \
     --resource-group $RESOURCE_GROUP \
     --min-replicas 0 \
     --scale-rule-name http-rule \
     --scale-rule-type http \
     --scale-rule-http-concurrency 10
   ```

2. **Use Spot Instances**: For non-critical workers
3. **Reserved Instances**: For production workloads (1-3 year commitment)
4. **Azure Hybrid Benefit**: If you have existing licenses
5. **Dev/Test Pricing**: For non-production environments

---

## 📊 Monitoring and Troubleshooting

### Application Insights Queries

```kusto
// View all requests
requests
| where timestamp > ago(1h)
| summarize count() by name, resultCode

// View exceptions
exceptions
| where timestamp > ago(1h)
| project timestamp, type, outerMessage, innermostMessage

// View dependencies (database calls)
dependencies
| where timestamp > ago(1h)
| summarize avg(duration) by name, type
```

### Container Logs

```bash
# View logs for a specific container app
az containerapp logs show \
  --name backend \
  --resource-group $RESOURCE_GROUP \
  --follow

# View logs for a specific revision
az containerapp revision list \
  --name backend \
  --resource-group $RESOURCE_GROUP

az containerapp logs show \
  --name backend \
  --resource-group $RESOURCE_GROUP \
  --revision <revision-name>
```

### Common Issues

#### Issue: Container fails to start

**Solution:**
```bash
# Check container app status
az containerapp show \
  --name backend \
  --resource-group $RESOURCE_GROUP \
  --query "properties.runningStatus"

# Check logs
az containerapp logs show \
  --name backend \
  --resource-group $RESOURCE_GROUP \
  --tail 100
```

#### Issue: Database connection fails

**Solution:**
1. Verify firewall rules allow Container Apps
2. Check connection string format
3. Verify credentials in Key Vault

#### Issue: Workers not processing tasks

**Solution:**
```bash
# Check worker logs
az containerapp logs show \
  --name store-create-worker \
  --resource-group $RESOURCE_GROUP \
  --follow

# Verify Camunda is accessible
curl https://$CAMUNDA_URL/engine-rest/engine
```

---

## 🎯 Next Steps

1. **Security Hardening**
   - Enable managed identities
   - Configure Azure AD authentication
   - Implement network policies
   - Enable Azure DDoS Protection

2. **High Availability**
   - Configure multi-region deployment
   - Set up Azure Front Door
   - Implement database geo-replication

3. **Backup and Disaster Recovery**
   - Configure automated backups
   - Test restore procedures
   - Document recovery procedures

4. **Performance Optimization**
   - Enable CDN for static assets
   - Configure caching strategies
   - Optimize database queries

---

## 📚 Additional Resources

- [Azure Container Apps Documentation](https://docs.microsoft.com/en-us/azure/container-apps/)
- [Azure Database for PostgreSQL](https://docs.microsoft.com/en-us/azure/postgresql/)
- [Azure Container Registry](https://docs.microsoft.com/en-us/azure/container-registry/)
- [Camunda Platform 7 Documentation](https://docs.camunda.org/manual/latest/)

---

**Need Help?** Contact your Azure support team or refer to the [Azure Support Portal](https://portal.azure.com/#blade/Microsoft_Azure_Support/HelpAndSupportBlade).
