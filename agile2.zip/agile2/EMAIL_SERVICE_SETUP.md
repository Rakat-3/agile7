# Real-Time Email Service Integration Guide

## Current Status: MailHog

**MailHog is actually running correctly!** It's a development tool that captures emails for testing. However, for **production/real-time notifications**, you need a proper email service.

---

## Production Email Service Options

### Option 1: SendGrid (Recommended - Easiest)

**Pros:**
- ✅ Free tier: 100 emails/day forever
- ✅ Very easy to set up (just API key)
- ✅ Excellent deliverability
- ✅ Good documentation
- ✅ No credit card required for free tier

**Pricing:**
- Free: 100 emails/day
- Essentials: $19.95/month (50,000 emails)
- Pro: $89.95/month (100,000 emails)

**Setup Steps:**

1. **Sign up**: Go to [SendGrid.com](https://sendgrid.com)
2. **Create API Key**:
   - Dashboard → Settings → API Keys
   - Create API Key with "Mail Send" permissions
   - Copy the key (you'll only see it once!)

3. **Update `.env` file**:
```bash
# SendGrid Configuration
SENDGRID_API_KEY=SG.your_api_key_here
FROM_EMAIL=noreply@yourdomain.com
```

4. **Update worker code** (already compatible!)

---

### Option 2: Azure Communication Services

**Pros:**
- ✅ Integrated with Azure ecosystem
- ✅ Good for Azure deployments
- ✅ Pay-as-you-go pricing
- ✅ Enterprise-grade reliability

**Pricing:**
- $0.00025 per email (very cheap!)
- First 100 emails/month free

**Setup Steps:**

1. **Create resource in Azure Portal**:
```bash
az communication create \
  --name "acs-contract-mgmt" \
  --resource-group "your-resource-group" \
  --location "global" \
  --data-location "United States"
```

2. **Get connection string**:
```bash
az communication list-key \
  --name "acs-contract-mgmt" \
  --resource-group "your-resource-group"
```

3. **Update `.env` file**:
```bash
# Azure Communication Services
ACS_CONNECTION_STRING=endpoint=https://...;accesskey=...
FROM_EMAIL=DoNotReply@yourdomain.com
```

---

### Option 3: Gmail SMTP (Quick & Free)

**Pros:**
- ✅ Completely free
- ✅ No signup needed (use existing Gmail)
- ✅ Quick setup

**Cons:**
- ⚠️ Limited to 500 emails/day
- ⚠️ Less professional
- ⚠️ Requires app password (2FA must be enabled)

**Setup Steps:**

1. **Enable 2-Factor Authentication** on your Gmail account

2. **Create App Password**:
   - Go to Google Account → Security
   - 2-Step Verification → App passwords
   - Generate password for "Mail"

3. **Update `.env` file**:
```bash
# Gmail SMTP
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your.email@gmail.com
SMTP_PASSWORD=your_app_password_here
FROM_EMAIL=your.email@gmail.com
```

---

### Option 4: AWS SES (Amazon Simple Email Service)

**Pros:**
- ✅ Very cheap ($0.10 per 1,000 emails)
- ✅ Highly scalable
- ✅ Good for AWS deployments

**Cons:**
- ⚠️ Starts in sandbox mode (need to request production access)
- ⚠️ More complex setup

**Pricing:**
- $0.10 per 1,000 emails
- Free tier: 62,000 emails/month (if sent from EC2)

---

## Recommended Choice

**For your project, I recommend SendGrid** because:
1. Free tier is generous (100/day)
2. Very easy to integrate
3. Excellent deliverability
4. No infrastructure needed
5. Works perfectly with your existing code

---

## Implementation Guide

### Step 1: Choose Your Service

I'll show you how to integrate **SendGrid** (easiest):

### Step 2: Update Environment Variables

Create/update `docker/.env`:

```bash
# SendGrid Configuration
SENDGRID_API_KEY=SG.your_actual_api_key_here
FROM_EMAIL=noreply@yourcompany.com
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
```

### Step 3: Update Email Worker

Your workers already support SMTP! Just update the environment variables in `docker-compose.yml`:

```yaml
legal-notify-worker:
  environment:
    - SMTP_HOST=smtp.sendgrid.net
    - SMTP_PORT=587
    - SMTP_USER=apikey
    - SMTP_PASSWORD=${SENDGRID_API_KEY}
    - FROM_EMAIL=noreply@yourcompany.com
```

### Step 4: Test Email Sending

```python
# Test script
import smtplib
from email.mime.text import MIMEText

msg = MIMEText("Test email from Contract Management System")
msg['Subject'] = 'Test Email'
msg['From'] = 'noreply@yourcompany.com'
msg['To'] = 'recipient@example.com'

with smtplib.SMTP('smtp.sendgrid.net', 587) as server:
    server.starttls()
    server.login('apikey', 'SG.your_api_key_here')
    server.send_message(msg)
    print("Email sent successfully!")
```

---

## Migration from MailHog to SendGrid

### Quick Migration Steps:

1. **Sign up for SendGrid** (5 minutes)
2. **Get API key** (2 minutes)
3. **Update `.env` file** (1 minute)
4. **Restart containers** (1 minute)

**Total time: ~10 minutes**

### Detailed Steps:

#### 1. Sign Up for SendGrid

```bash
# Go to: https://signup.sendgrid.com/
# Fill in your details
# Verify your email
```

#### 2. Create API Key

```bash
# In SendGrid Dashboard:
# Settings → API Keys → Create API Key
# Name: "Contract Management System"
# Permissions: "Mail Send" (Full Access)
# Copy the key immediately!
```

#### 3. Update Configuration Files

**Update `docker/.env`:**
```bash
# Add these lines
SENDGRID_API_KEY=SG.your_actual_key_here
FROM_EMAIL=noreply@yourcompany.com
```

**Update `docker-compose.yml`:**

Replace MailHog environment variables in workers:

```yaml
legal-notify-worker:
  environment:
    - SMTP_HOST=smtp.sendgrid.net
    - SMTP_PORT=587
    - SMTP_USER=apikey
    - SMTP_PASSWORD=${SENDGRID_API_KEY}
    - FROM_EMAIL=${FROM_EMAIL}
```

#### 4. Restart Services

```bash
cd docker
docker compose down
docker compose up -d
```

---

## Comparison Table

| Feature | MailHog | SendGrid | Azure ACS | Gmail SMTP | AWS SES |
|---------|---------|----------|-----------|------------|---------|
| **Purpose** | Testing | Production | Production | Testing/Small | Production |
| **Cost** | Free | Free tier | Pay-per-use | Free | Pay-per-use |
| **Daily Limit** | Unlimited | 100 (free) | Unlimited | 500 | Unlimited |
| **Setup Time** | 0 min | 10 min | 20 min | 15 min | 30 min |
| **Deliverability** | N/A | Excellent | Excellent | Good | Excellent |
| **Real Emails** | ❌ No | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |
| **Production Ready** | ❌ No | ✅ Yes | ✅ Yes | ⚠️ Limited | ✅ Yes |

---

## Code Changes Required

**Good news: ZERO code changes needed!** Your workers already use SMTP, so you just need to:

1. Update environment variables
2. Restart containers

That's it! 🎉

---

## Testing Your Email Service

After setup, test with this command:

```bash
# Send a test email through your worker
docker logs legal-notify-worker --tail 50

# Check for successful send messages
# You should see: "Email sent successfully to..."
```

---

## Troubleshooting

### SendGrid Issues

**Problem:** "Authentication failed"
**Solution:** Make sure you're using `apikey` as username and your API key as password

**Problem:** "Sender not verified"
**Solution:** Verify your sender email in SendGrid dashboard

### Gmail SMTP Issues

**Problem:** "Username and Password not accepted"
**Solution:** Use App Password, not your regular Gmail password

### General Issues

**Problem:** Emails not arriving
**Solution:** 
1. Check spam folder
2. Verify sender email is valid
3. Check worker logs for errors

---

## Next Steps

1. **Choose your email service** (I recommend SendGrid)
2. **Sign up and get credentials**
3. **Update `.env` file**
4. **Update `docker-compose.yml`**
5. **Restart containers**
6. **Test email sending**

Would you like me to help you set up SendGrid or another service?
