import pyodbc
import os
import sys

def apply_schema():
    server = 'rakat-sqlsrv-01.database.windows.net'
    database = 'free-sql-db-2967320'
    username = 'sqladmin'
    password = 'Agile_group'
    driver = '{ODBC Driver 18 for SQL Server}'

    conn_str = f'DRIVER={driver};SERVER={server};PORT=1433;DATABASE={database};UID={username};PWD={password};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;'

    try:
        print("Connecting to Azure SQL...")
        conn = pyodbc.connect(conn_str, autocommit=False)
        cursor = conn.cursor()
        
        # Drop tables in correct order (child first)
        print("Dropping existing tables...")
        cursor.execute("IF OBJECT_ID('dbo.ProviderOffers', 'U') IS NOT NULL DROP TABLE dbo.ProviderOffers")
        cursor.execute("IF OBJECT_ID('dbo.Contracts', 'U') IS NOT NULL DROP TABLE dbo.Contracts")
        conn.commit()
        
        # Create Contracts table
        print("Creating Contracts table...")
        cursor.execute("""
            CREATE TABLE dbo.Contracts (
                Id INT IDENTITY(1, 1) PRIMARY KEY,
                ContractId UNIQUEIDENTIFIER NOT NULL,
                ProcessInstanceId NVARCHAR(64) NULL,
                BusinessKey NVARCHAR(255) NULL,
                ContractTitle NVARCHAR(255) NULL,
                ContractType NVARCHAR(255) NULL,
                Roles NVARCHAR(MAX) NULL,
                Skills NVARCHAR(MAX) NULL,
                RequestType NVARCHAR(255) NULL,
                Budget FLOAT NULL,
                ContractStartDate NVARCHAR(50) NULL,
                ContractEndDate NVARCHAR(50) NULL,
                Description NVARCHAR(MAX) NULL,
                Deadline NVARCHAR(50) NULL,
                ProvidersBudget INT NULL,
                ProvidersComment NVARCHAR(MAX) DEFAULT '',
                ProvidersName NVARCHAR(255) NULL,
                SignedDate NVARCHAR(50) NULL,
                ApprovedAt DATETIME2 NULL,
                LegalComment NVARCHAR(MAX) NULL,
                ApprovalDecision NVARCHAR(50) NULL,
                ContractStatus NVARCHAR(50) DEFAULT 'Running',
                CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                EmployeeName NVARCHAR(255) NULL,
                OfficeAddress NVARCHAR(255) NULL,
                FinalPrice FLOAT NULL,
                MeetRequirement NVARCHAR(50) NULL
            )
        """)
        conn.commit()
        
        print("Creating unique index...")
        cursor.execute("CREATE UNIQUE INDEX UX_Contracts_ContractId ON dbo.Contracts(ContractId)")
        conn.commit()
        
        # Create ProviderOffers table
        print("Creating ProviderOffers table...")
        cursor.execute("""
            CREATE TABLE dbo.ProviderOffers (
                Id INT IDENTITY(1, 1) PRIMARY KEY,
                ContractId UNIQUEIDENTIFIER NOT NULL,
                ProvidersName NVARCHAR(255) NULL,
                ProvidersBudget INT NULL,
                ProvidersComment NVARCHAR(MAX) NULL,
                MeetRequirement NVARCHAR(50) NULL,
                SubmittedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
                FOREIGN KEY (ContractId) REFERENCES dbo.Contracts(ContractId)
            )
        """)
        conn.commit()
        
        print("Schema applied successfully!")
        print("✅ Contracts table created with Deadline column")
        print("✅ ProviderOffers table created")
        
        conn.close()
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    apply_schema()
